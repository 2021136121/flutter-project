package com.example.music1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
