import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // Android 전용 빌드, 별도 플랫폼 분기 없음
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '기분 기반 음악 추천',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: MoodMusicScreen(),
    );
  }
}

class MoodMusicScreen extends StatefulWidget {
  @override
  _MoodMusicScreenState createState() => _MoodMusicScreenState();
}

class _MoodMusicScreenState extends State<MoodMusicScreen> {
  // Spotify API 정보 - 본인 값으로 바꿔주세요
  final String clientId = '56d013862fc74895afab23cb63a5c759';
  final String clientSecret = 'b933f6864b0a416b81ca51d087a675ae';

  String? _accessToken;
  bool _isLoading = false;
  List<dynamic> _tracks = [];

  // 기분과 매칭된 장르 (예시)
  final Map<String, String> moodToGenre = {
    '😊': 'pop',
    '😢': 'Acoustic',
    '😎': 'EDM',
    '😌': 'jazz',
    '😡': 'Punk',
  };

  String? _selectedMood;
  String? _selectedGenre;

  @override
  void initState() {
    super.initState();
    fetchSpotifyToken();
  }

  Future<void> fetchSpotifyToken() async {
    final String basicAuth = base64Encode(utf8.encode('$clientId:$clientSecret'));

    final response = await http.post(
      Uri.parse('https://accounts.spotify.com/api/token'),
      headers: {
        'Authorization': 'Basic $basicAuth',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'grant_type=client_credentials',
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        _accessToken = data['access_token'];
      });
    } else {
      print('Failed to get token: ${response.statusCode}');
    }
  }

  Future<void> fetchTopTracks(String genre) async {
    if (_accessToken == null) return;

    setState(() {
      _isLoading = true;
      _tracks = [];
    });

    // Spotify는 장르별 top 10 곡 조회 API가 없으므로, search API로 genre 검색 (트랙 제한 10개)
    final response = await http.get(
      Uri.parse(
          'https://api.spotify.com/v1/search?q=genre:$genre&type=track&limit=10'),
      headers: {
        'Authorization': 'Bearer $_accessToken',
      },
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        _tracks = data['tracks']['items'];
        _isLoading = false;
      });
    } else {
      print('Failed to fetch tracks: ${response.statusCode}');
      setState(() {
        _isLoading = false;
      });
    }
  }

  Widget moodButton(String moodEmoji) {
    return ElevatedButton(
      onPressed: () {
        setState(() {
          _selectedMood = moodEmoji;
          _selectedGenre = moodToGenre[moodEmoji];
        });
        if (_selectedGenre != null) {
          fetchTopTracks(_selectedGenre!);
        }
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: _selectedMood == moodEmoji ? Colors.blue : Colors.grey,
        shape: CircleBorder(),
        padding: EdgeInsets.all(16),
      ),
      child: Text(
        moodEmoji,
        style: TextStyle(fontSize: 28),
      ),
    );
  }

  Widget trackTile(dynamic track) {
    final artists = (track['artists'] as List)
        .map((artist) => artist['name'])
        .join(', ');
    return ListTile(
      leading: track['album']['images'].length > 0
          ? Image.network(track['album']['images'][0]['url'], width: 50)
          : null,
      title: Text(track['name']),
      subtitle: Text(artists),
      onTap: () {
        // TODO: 플레이어 추가 가능
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('기분 기반 음악 추천'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text('기분을 선택하세요', style: TextStyle(fontSize: 20)),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: moodToGenre.keys.map((e) => moodButton(e)).toList(),
            ),
            SizedBox(height: 20),
            if (_selectedGenre != null)
              Text('추천 장르: $_selectedGenre', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Expanded(
              child: _isLoading
                  ? Center(child: CircularProgressIndicator())
                  : ListView.builder(
                itemCount: _tracks.length,
                itemBuilder: (context, index) {
                  return trackTile(_tracks[index]);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
