import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class GalleryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final userId = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      appBar: AppBar(title: Text('갤러리')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('diaries')
            .where('userId', isEqualTo: userId)
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          final docs = snapshot.data?.docs ?? [];

          if (docs.isEmpty) {
            return Center(child: Text('작성된 일기가 없습니다.'));
          }

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final title = doc['title'] ?? '제목 없음';
              final text = doc['text'] ?? '';
              final mood = doc['mood'] ?? '';
              final imageUrl = doc['imageUrl'];
              final timestamp = (doc['timestamp'] as Timestamp).toDate();
              final formattedDate =
                  '${timestamp.year}.${timestamp.month.toString().padLeft(2, '0')}.${timestamp.day.toString().padLeft(2, '0')}';
              final recommendedTracks = doc['recommendedTracks'] as List<dynamic>?;

              return ExpansionTile(
                title: Text(title),
                subtitle: Text(formattedDate),
                children: [
                  if (imageUrl != null)
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Image.network(imageUrl),
                    ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('기분: $mood'),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(text),
                  ),
                  if (recommendedTracks != null && recommendedTracks.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 10),
                          Text('이 날 추천받은 곡:', style: TextStyle(fontWeight: FontWeight.bold)),
                          SizedBox(height: 6),
                          ...recommendedTracks.map((track) {
                            final trackName = track['name'] ?? '제목 없음';
                            final artists = (track['artists'] as List).join(', ');
                            final image = track['imageUrl'];
                            return ListTile(
                              leading: image != null ? Image.network(image, width: 50, height: 50) : null,
                              title: Text(trackName),
                              subtitle: Text(artists),
                            );
                          }).toList(),
                        ],
                      ),
                    ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}
