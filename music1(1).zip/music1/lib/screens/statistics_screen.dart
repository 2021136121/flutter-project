import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class StatsScreen extends StatefulWidget {
  @override
  _StatsScreenState createState() => _StatsScreenState();
}

class _StatsScreenState extends State<StatsScreen> {
  Map<String, int> moodCounts = {};
  final List<String> moodEmojis = [
    '😊', '😢', '😎', '😌', '😡', '😱', '😍', '😴', '🤩', '🤔'
  ];

  @override
  void initState() {
    super.initState();
    _fetchMoodCounts();
  }

  Future<void> _fetchMoodCounts() async {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    final snapshot = await FirebaseFirestore.instance
        .collection('diaries')
        .where('userId', isEqualTo: userId)
        .get();

    Map<String, int> counts = {};
    for (var doc in snapshot.docs) {
      final mood = doc['mood'];
      counts[mood] = (counts[mood] ?? 0) + 1;
    }

    setState(() {
      moodCounts = counts;
    });
  }

  @override
  Widget build(BuildContext context) {
    int maxCount = moodCounts.values.fold(0, (prev, e) => e > prev ? e : prev);
    int yMax = ((maxCount + 4) ~/ 5) * 5;

    return Scaffold(
      appBar: AppBar(title: Text('감정 통계')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: moodCounts.isEmpty
            ? Center(child: Text('감정 데이터가 없습니다.'))
            : BarChart(
          BarChartData(
            maxY: yMax.toDouble(),
            titlesData: FlTitlesData(
              show: true,
              topTitles: AxisTitles(
                sideTitles: SideTitles(showTitles: false),
              ),
              leftTitles: AxisTitles(
                sideTitles: SideTitles(showTitles: false),
              ),
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  getTitlesWidget: (value, meta) {
                    int index = value.toInt();
                    return Text(
                      index < moodEmojis.length ? moodEmojis[index] : '',
                      style: TextStyle(fontSize: 16),
                    );
                  },
                ),
              ),
              rightTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  interval: 5,
                  getTitlesWidget: (value, meta) {
                    if (value % 5 == 0) {
                      return Text(value.toInt().toString());
                    }
                    return Container();
                  },
                ),
              ),
            ),
            gridData: FlGridData(
              show: true,
              drawVerticalLine: false,
              horizontalInterval: 5,
            ),
            borderData: FlBorderData(show: false),
            barGroups: moodEmojis.asMap().entries.map((entry) {
              final index = entry.key;
              final emoji = entry.value;
              final count = moodCounts[emoji] ?? 0;
              return BarChartGroupData(
                x: index,
                barRods: [
                  BarChartRodData(
                    toY: count.toDouble(),
                    width: 18,
                    color: Colors.blue,
                  )
                ],
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}
