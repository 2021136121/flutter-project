import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../main.dart';

class MoodMusicScreen extends StatefulWidget {
  final String selectedMood;

  const MoodMusicScreen({Key? key, required this.selectedMood}) : super(key: key);

  @override
  _MoodMusicScreenState createState() => _MoodMusicScreenState();
}

class _MoodMusicScreenState extends State<MoodMusicScreen> {
  List<dynamic> _tracks = [];
  bool _isLoading = true;

  final Map<String, String> moodGenreMap = {
    '😊': 'pop',
    '😢': 'acoustic',
    '😎': 'edm',
    '😌': 'ambient',
    '😡': 'metal',
    '😱': 'electronic',
    '😍': 'soul',
    '😴': 'chill',
    '🤩': 'dance',
    '🤔': 'indie',
  };

  final String clientId = '56d013862fc74895afab23cb63a5c759';
  final String clientSecret = 'b933f6864b0a416b81ca51d087a675ae';

  @override
  void initState() {
    super.initState();
    _fetchMusic();
  }

  Future<void> _fetchMusic() async {
    final genre = moodGenreMap[widget.selectedMood];
    if (genre == null) {
      setState(() {
        _isLoading = false;
      });
      return;
    }

    try {
      final credentials = base64.encode(utf8.encode('$clientId:$clientSecret'));

      final tokenResponse = await http.post(
        Uri.parse('https://accounts.spotify.com/api/token'),
        headers: {
          'Authorization': 'Basic $credentials',
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: {'grant_type': 'client_credentials'},
      );

      final tokenData = json.decode(tokenResponse.body);
      final accessToken = tokenData['access_token'];

      final response = await http.get(
        Uri.parse(
            'https://api.spotify.com/v1/search?q=genre:%22$genre%22&type=track&limit=10'),
        headers: {
          'Authorization': 'Bearer $accessToken',
          'Content-Type': 'application/json',
        },
      );

      final data = json.decode(response.body);
      final tracks = data['tracks']['items'];

      setState(() {
        _tracks = tracks;
        _isLoading = false;
      });
    } catch (e) {
      print('에러 발생: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final moodEmoji = widget.selectedMood;
    return Scaffold(
      appBar: AppBar(title: Text('기분 기반 음악 추천')),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              '당신의 기분 $moodEmoji에 추천할만한 음악',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: _tracks.isEmpty
                ? Center(child: Text('추천된 곡이 없습니다.'))
                : ListView.builder(
              itemCount: _tracks.length,
              itemBuilder: (context, index) {
                final track = _tracks[index];
                return ListTile(
                  leading: Image.network(
                    track['album']['images'][0]['url'],
                    width: 50,
                    height: 50,
                  ),
                  title: Text(track['name']),
                  subtitle: Text(track['artists']
                      .map<String>((a) => a['name'].toString())
                      .join(', ')),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton.icon(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => MainDiaryScreen()),
                );
              },
              icon: Icon(Icons.arrow_back),
              label: Text('메인 화면으로 돌아가기'),
              style: ElevatedButton.styleFrom(
                minimumSize: Size.fromHeight(50),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
