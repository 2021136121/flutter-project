import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:music1/screens/statistics_screen.dart';
import '../main.dart';
import 'gallery_screen.dart';

class HomeMenuScreen extends StatefulWidget {
  @override
  _HomeMenuScreenState createState() => _HomeMenuScreenState();
}

class _HomeMenuScreenState extends State<HomeMenuScreen> {
  bool _isDarkMode = false;

  @override
  void initState() {
    super.initState();
    _isDarkMode = themeNotifier.value == ThemeMode.dark;
  }

  void _toggleTheme(bool value) {
    setState(() {
      _isDarkMode = value;
      themeNotifier.value = _isDarkMode ? ThemeMode.dark : ThemeMode.light;
    });
  }

  void _navigateTo(Widget screen) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => screen),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('홈 메뉴')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton.icon(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => MainDiaryScreen()),
                );
              },
              icon: Icon(Icons.edit),
              label: Text('일기 작성'),
            ),
            SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => GalleryScreen()),
                );
              },
              icon: Icon(Icons.photo_library),
              label: Text('갤러리'),
            ),
            SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => StatsScreen()),
                );
              },
              icon: Icon(Icons.bar_chart),
              label: Text('통계 보기'),
            ),
            SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () async {
                await FirebaseAuth.instance.signOut();
                Navigator.of(context).pushNamedAndRemoveUntil('/', (route) => false);
              },
              icon: Icon(Icons.logout),
              label: Text('로그아웃'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
            ),
            Spacer(), // 여기서 아래로 밀어줌
            Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('다크 모드', style: TextStyle(fontSize: 16)),
                Switch(
                  value: _isDarkMode,
                  onChanged: _toggleTheme,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
