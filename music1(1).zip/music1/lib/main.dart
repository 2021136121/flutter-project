import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:music1/firebase_options.dart';
import 'package:music1/screens/splash_screen.dart';
import 'screens/mood_music_screen.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, ThemeMode currentMode, __) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Mood Music',
          theme: ThemeData.light(),
          darkTheme: ThemeData.dark(),
          themeMode: currentMode,
          home: SplashScreen(),
        );
      },
    );
  }
}

class MainDiaryScreen extends StatefulWidget {
  @override
  _MainDiaryScreenState createState() => _MainDiaryScreenState();
}

class _MainDiaryScreenState extends State<MainDiaryScreen> {
  String? _selectedMood;
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _diaryController = TextEditingController();
  File? _selectedImage;

  final String clientId = '56d013862fc74895afab23cb63a5c759';
  final String clientSecret = 'b933f6864b0a416b81ca51d087a675ae';

  final Map<String, String> moodLabels = {
    '😊': '행복',
    '😢': '슬픔',
    '😎': '자신감',
    '😌': '편안',
    '😡': '화남',
    '😱': '불안',
    '😍': '설렘',
    '😴': '피곤',
    '🤩': '신남',
    '🤔': '고민'
  };

  final Map<String, String> moodGenreMap = {
    '😊': 'pop',
    '😢': 'acoustic',
    '😎': 'edm',
    '😌': 'ambient',
    '😡': 'metal',
    '😱': 'electronic',
    '😍': 'soul',
    '😴': 'chill',
    '🤩': 'dance',
    '🤔': 'indie',
  };

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        _selectedImage = File(picked.path);
      });
    }
  }

  void _showMoodPicker() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.45,
          minChildSize: 0.3,
          maxChildSize: 0.8,
          expand: false,
          builder: (context, scrollController) {
            return Padding(
              padding: const EdgeInsets.all(16),
              child: SingleChildScrollView(
                controller: scrollController,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        margin: EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: Colors.grey[400],
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                    Text("기분을 선택하세요", style: TextStyle(fontSize: 16)),
                    SizedBox(height: 12),
                    Wrap(
                      alignment: WrapAlignment.center,
                      spacing: 16,
                      runSpacing: 16,
                      children: moodLabels.keys.map((emoji) {
                        return GestureDetector(
                          onTap: () {
                            setState(() => _selectedMood = emoji);
                            Navigator.pop(context);
                          },
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              CircleAvatar(
                                radius: 26,
                                backgroundColor: _selectedMood == emoji
                                    ? Colors.blue.shade100
                                    : Colors.grey.shade200,
                                child: Text(emoji, style: TextStyle(fontSize: 24)),
                              ),
                              SizedBox(height: 6),
                              Text(
                                moodLabels[emoji]!,
                                style: TextStyle(fontSize: 12),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<List<Map<String, dynamic>>> _getRecommendedTracks(String genre) async {
    final credentials = base64.encode(utf8.encode('$clientId:$clientSecret'));

    final tokenResponse = await http.post(
      Uri.parse('https://accounts.spotify.com/api/token'),
      headers: {
        'Authorization': 'Basic $credentials',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: {'grant_type': 'client_credentials'},
    );

    final accessToken = json.decode(tokenResponse.body)['access_token'];

    final trackResponse = await http.get(
      Uri.parse('https://api.spotify.com/v1/search?q=genre:$genre&type=track&limit=10'),
      headers: {
        'Authorization': 'Bearer $accessToken',
        'Content-Type': 'application/json',
      },
    );

    final items = json.decode(trackResponse.body)['tracks']['items'];
    return items.map<Map<String, dynamic>>((track) => {
      'name': track['name'],
      'artists': (track['artists'] as List).map((a) => a['name']).toList(),
      'imageUrl': track['album']['images'][0]['url'],
      'spotifyUrl': track['external_urls']['spotify'],
    }).toList();
  }

  Future<void> _saveDiary() async {
    if (_selectedMood == null ||
        _diaryController.text.isEmpty ||
        _titleController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('기분, 제목, 일기를 모두 입력해주세요.')),
      );
      return;
    }

    try {
      String? imageUrl;
      if (_selectedImage != null) {
        final ref = FirebaseStorage.instance
            .ref()
            .child('images')
            .child('${DateTime.now().millisecondsSinceEpoch}.jpg');
        await ref.putFile(_selectedImage!);
        imageUrl = await ref.getDownloadURL();
      }

      final genre = moodGenreMap[_selectedMood];
      final recommendedTracks = await _getRecommendedTracks(genre!);

      await FirebaseFirestore.instance.collection('diaries').add({
        'mood': _selectedMood,
        'title': _titleController.text,
        'text': _diaryController.text,
        'imageUrl': imageUrl,
        'timestamp': Timestamp.now(),
        'userId': FirebaseAuth.instance.currentUser?.uid,
        'recommendedTracks': recommendedTracks,
      });

      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('저장 완료'),
          content: Text('일기가 저장되었습니다!'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (context) => MoodMusicScreen(selectedMood: _selectedMood!),
                  ),
                );
              },
              child: Text('확인'),
            ),
          ],
        ),
      );
    } catch (e) {
      print('저장 중 오류: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('저장 중 오류가 발생했습니다.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('오늘의 일기')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text('오늘의 기분은 어떠신가요?', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            ElevatedButton.icon(
              onPressed: _showMoodPicker,
              icon: Icon(Icons.emoji_emotions),
              label: Text(
                _selectedMood != null
                    ? '선택된 기분: $_selectedMood (${moodLabels[_selectedMood!]})'
                    : '기분 선택',
              ),
              style: ElevatedButton.styleFrom(
                minimumSize: Size.fromHeight(40),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _titleController,
              decoration: InputDecoration(
                hintText: '제목을 입력하세요',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _diaryController,
              maxLines: 5,
              decoration: InputDecoration(
                hintText: '오늘의 감정을 일기로 표현해보세요...',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: _pickImage,
                  icon: Icon(Icons.image),
                  label: Text('이미지 추가'),
                ),
                SizedBox(width: 10),
                if (_selectedImage != null)
                  Image.file(_selectedImage!, width: 80, height: 80),
              ],
            ),
            Spacer(),
            ElevatedButton(
              onPressed: _saveDiary,
              child: Text('저장'),
              style: ElevatedButton.styleFrom(minimumSize: Size.fromHeight(50)),
            ),
            SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}
